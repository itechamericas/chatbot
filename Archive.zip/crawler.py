import os, re, time, urllib.parse, collections
import requests
from bs4 import BeautifulSoup

USER_AGENT = os.getenv("CRAWLER_UA", "Mozilla/5.0 (compatible; iTechAmericasBot/1.0)")

def normalize_url(base, link=""):
    try:
        url = urllib.parse.urljoin(base, link)
        url, _ = urllib.parse.urldefrag(url)
        return url
    except Exception:
        return None

def same_domain(u1, u2):
    try:
        n1 = urllib.parse.urlparse(u1).netloc
        n2 = urllib.parse.urlparse(u2).netloc
        return n1 == n2
    except Exception:
        return False

def extract_text(html):
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    text = soup.get_text(separator="\n")
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    return "\n".join(lines)[:120000]

def crawl_and_extract(start_url, max_pages=30, max_depth=2, same_domain_only=True, timeout=12):
    start_url = normalize_url(start_url, "")
    visited = set()
    q = collections.deque()
    q.append((start_url, 0))
    results = []

    headers = {"User-Agent": USER_AGENT}

    while q and len(results) < max_pages:
        url, depth = q.popleft()
        if url in visited: 
            continue
        visited.add(url)

        try:
            r = requests.get(url, headers=headers, timeout=timeout)
            if r.status_code >= 400 or "text/html" not in (r.headers.get("Content-Type") or ""):
                continue
            text = extract_text(r.text)
            if len(text) > 1000:
                results.append((url, text))

            if depth < max_depth:
                soup = BeautifulSoup(r.text, "html.parser")
                for a in soup.find_all("a", href=True):
                    nxt = normalize_url(url, a["href"]) or ""
                    if same_domain_only and not same_domain(start_url, nxt):
                        continue
                    if any(ext in nxt.lower() for ext in [".pdf", ".zip", ".png", ".jpg", ".jpeg", ".gif", ".svg", "mailto:", "tel:"]):
                        continue
                    if nxt not in visited:
                        q.append((nxt, depth+1))
        except Exception:
            continue
    return results
