import os
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .chatbot import get_chat_response
from .database import create_tables, save_message
from dotenv import load_dotenv

# Load env variables from .env
load_dotenv()

API_KEY = os.getenv("INTERNAL_API_KEY")

app = FastAPI()

# Enable CORS only for your frontend (replace with your domain)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # <--- change this
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    create_tables()

@app.post("/chat")
async def chat(request: Request):
    # 🔐 API key validation
    if request.headers.get("x-api-key") != API_KEY:
        raise HTTPException(status_code=403, detail="Forbidden")

    body = await request.json()
    user_message = body.get("message", "")
    session_id = body.get("session_id", "default")

    response = get_chat_response(user_message)
    save_message(session_id, user_message, response)
    return {"response": response}


from fastapi import UploadFile, File
from typing import List
import uuid, io

def _chunk(text, maxlen=1200):
    text = text.replace('\r','')
    paras = text.split('\n')
    chunks = []
    cur = ''
    for p in paras:
        if len(cur) + len(p) + 1 < maxlen:
            cur += ('\n' if cur else '') + p
        else:
            if cur: chunks.append(cur)
            cur = p
    if cur: chunks.append(cur)
    return chunks

@app.post('/ingest/text')
async def ingest_text(request: Request):
    if request.headers.get('x-api-key') != API_KEY:
        raise HTTPException(status_code=403, detail='Forbidden')
    body = await request.json()
    text = body.get('text','')
    source = body.get('source','runtime.txt')
    added = 0
    for ch in _chunk(text, 1200):
        if add_document_to_faiss(f"{source}\n\n{ch}", source=source):
            added += 1
    return {'ok': True, 'added': added}

@app.post('/ingest/upload')
async def ingest_upload(request: Request, files: List[UploadFile] = File(...)):
    if request.headers.get('x-api-key') != API_KEY:
        raise HTTPException(status_code=403, detail='Forbidden')
    added = 0
    for uf in files:
        try:
            content = (await uf.read())
            name = uf.filename or f'upload_{uuid.uuid4()}'
            text = ''
            low = (name or '').lower()
            if low.endswith('.pdf'):
                try:
                    import PyPDF2
                    reader = PyPDF2.PdfReader(io.BytesIO(content))
                    for page in reader.pages:
                        text += page.extract_text() or ''
                except Exception:
                    pass
            elif low.endswith('.docx'):
                try:
                    import docx
                    doc = docx.Document(io.BytesIO(content))
                    text = '\n'.join([p.text for p in doc.paragraphs])
                except Exception:
                    pass
            else:
                try:
                    text = content.decode('utf-8', errors='ignore')
                except Exception:
                    text = ''

            for ch in _chunk(text, 1200):
                if add_document_to_faiss(f"{name}\n\n{ch}", source=name):
                    added += 1
        except Exception:
            continue
    return {'ok': True, 'added': added}

try:
    from crawler import crawl_and_extract
except Exception:
    from .crawler import crawl_and_extract

@app.post('/ingest/url')
async def ingest_url(request: Request):
    if request.headers.get('x-api-key') != API_KEY:
        raise HTTPException(status_code=403, detail='Forbidden')
    body = await request.json()
    url = body.get('url')
    max_pages = int(body.get('max_pages', 30))
    max_depth = int(body.get('max_depth', 2))
    same_domain = bool(body.get('same_domain', True))

    if not url:
        raise HTTPException(status_code=400, detail='Missing url')

    pages = crawl_and_extract(url, max_pages=max_pages, max_depth=max_depth, same_domain_only=same_domain)
    pages_ingested = 0
    for pg_url, text in pages:
        src = f'crawl:{pg_url}'
        for ch in _chunk(text, 1200):
            if add_document_to_faiss(f"{src}\n\n{ch}", source=src):
                pages_ingested += 1
    return {'ok': True, 'pages_ingested': pages_ingested, 'start_url': url, 'pages_seen': len(pages)}
