import os
from openai import OpenAI
try:
    from backend.faiss_index import search_faiss
except Exception:
    from faiss_index import search_faiss

# Initialize OpenAI with your API key
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def get_chat_response(user_input: str) -> str:
    try:
        greetings = ["hi", "hello", "hey", "good morning", "good afternoon", "good evening"]
        if user_input.strip().lower() in greetings:
            return "Hello! How can I assist you today?"

        # Search your indexed knowledge base
        top_matches = search_faiss(user_input, k=3)

        if not top_matches:
            return "I'm sorry, I can only assist with questions related to iTech Americas LLC and our services."

        context = "\n---\n".join(top_matches)

        # Compose prompt with context
        prompt = f"""
You are a smart, professional, and friendly AI assistant developed by iTech Americas LLC. Your role is to assist users by providing helpful, accurate, and clear information specifically about iTech Americas LLC, including our services, support options, business operations, appointment scheduling, product inquiries, and technical solutions.

Always remain focused on topics directly related to iTech Americas LLC. If a user asks a question that is unrelated to iTech Americas LLC or outside your defined role, politely respond with:

"I'm here to assist you with questions related to iTech Americas LLC and our services. Please let me know how I can help in that area."

Never attempt to answer unrelated, personal, or off-topic questions. Maintain a helpful, professional tone, and represent the values and brand of iTech Americas LLC in all responses. reply:
"I'm sorry, I can only assist with questions related to iTech Americas LLC and our services."
Context:
{context}

User question: {user_input}
Answer:"""

        # Query OpenAI for final answer
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content": "You are a knowledgeable and concise assistant."},
                {"role": "user", "content": prompt}
            ]
        )

        return response.choices[0].message.content.strip()

    except Exception as e:
        print(f"[Chatbot ERROR] {e}")
        return "I'm sorry, I can only assist with questions related to iTech Americas LLC and our services."

