
# AI Assistant – Voice + RAG + Streamlit Frontend

## 1) Environment
Create a `.env` with:
```
OPENAI_API_KEY=sk-...
INTERNAL_API_KEY=changeme
OPENAI_CHAT_MODEL=gpt-4o-mini
OPENAI_TTS_MODEL=gpt-4o-mini-tts
OPENAI_STT_MODEL=whisper-1
BACKEND_URL=https://localhost:9000
```

## 2) Run (Docker Compose)
```
docker compose up --build
```
- Backend on `https://localhost:9000/`
- Frontend on `http://localhost:8555/`

## 3) Endpoints (added)
- `POST /audio/transcribe` – upload audio, get transcript
- `GET  /audio/tts?text=...&voice=alloy` – get MP3
- `POST /chat/voice` – upload audio, get transcript + text + base64 MP3
- `POST /feedback` – save rating/comment for message_id
- `GET  /export/messages.csv` – download all messages
- (Optional) `POST /ingest/text` – add-text-to-index endpoint if you create it

## 4) Frontend
- Streamlit app with tabs: Chat, Voice, Knowledge, Insights
- Settings in sidebar (backend URL, API key, voice, session)
