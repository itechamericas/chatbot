
import os
import base64
from typing import Optional
from openai import OpenAI

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Defaults can be overridden by env
TTS_MODEL = os.getenv("OPENAI_TTS_MODEL", "gpt-4o-mini-tts")
STT_MODEL = os.getenv("OPENAI_STT_MODEL", "whisper-1")

def text_to_speech_bytes(text: str, voice: str = "alloy", format: str = "mp3") -> bytes:
    """
    Return audio bytes for given text using OpenAI TTS.
    """
    if not text:
        return b""
    try:
        resp = client.audio.speech.create(
            model=TTS_MODEL,
            voice=voice,
            input=text,
            format=format
        )
        # SDK may return bytes already; ensure bytes
        audio_b64 = getattr(resp, "audio", None)
        if audio_b64 and isinstance(audio_b64, str):
            return base64.b64decode(audio_b64)
        # Some SDK versions expose .content or .to_bytes()
        if hasattr(resp, "to_bytes"):
            return resp.to_bytes()
        if hasattr(resp, "content"):
            return resp.content
        return bytes(resp)
    except Exception as e:
        print(f"[TTS ERROR] {e}")
        return b""

def speech_to_text(file_path: str, language: Optional[str] = None) -> str:
    """
    Transcribe audio file at `file_path` to text using OpenAI Whisper (server-side).
    Accepts common formats like mp3, m4a, wav, webm.
    """
    try:
        with open(file_path, "rb") as f:
            resp = client.audio.transcriptions.create(
                model=STT_MODEL,
                file=f,
                language=language
            )
        # SDK may return resp.text or resp["text"]
        if hasattr(resp, "text"):
            return resp.text
        return resp.get("text", "")
    except Exception as e:
        print(f"[STT ERROR] {e}")
        return ""
