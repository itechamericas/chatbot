import os
import faiss
import pickle
import numpy as np
from typing import List, Tuple
from openai import OpenAI
try:
    from backend.knowledge_loader import load_all_documents
except Exception:
    from knowledge_loader import load_all_documents

# Initialize OpenAI
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Paths to save the FAISS index and metadata
INDEX_FILE = "data/faiss.index"
META_FILE = "data/faiss_meta.pkl"

def get_embedding(text: str) -> List[float]:
    """
    Generate an embedding using OpenAI's embedding model.
    """
    try:
        response = client.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
        return response.data[0].embedding
    except Exception as e:
        print(f"[EMBEDDING ERROR] {e}")
        return []

def build_faiss_index():
    """
    Build and save FAISS index from all documents.
    """
    print("[INFO] Loading documents for FAISS indexing...")
    documents = load_all_documents()

    if not documents:
        print("[ERROR] No documents found to index.")
        return

    texts = [content for _, content in documents]
    sources = [f"{filename}" for filename, _ in documents]

    print(f"[INFO] Generating {len(texts)} embeddings...")
    embeddings = [get_embedding(text) for text in texts]

    if not embeddings or not embeddings[0]:
        print("[ERROR] Embeddings could not be created.")
        return

    dimension = len(embeddings[0])
    index = faiss.IndexFlatL2(dimension)
    index.add(np.array(embeddings).astype("float32"))

    faiss.write_index(index, INDEX_FILE)
    with open(META_FILE, "wb") as f:
        pickle.dump(list(zip(sources, texts)), f)

    print("[INFO] FAISS index built and saved.")

def load_faiss_index() -> Tuple[faiss.IndexFlatL2, List[Tuple[str, str]]]:
    """
    Load the FAISS index and document metadata.
    """
    if not os.path.exists(INDEX_FILE) or not os.path.exists(META_FILE):
        print("[INFO] No FAISS index found. Building now...")
        build_faiss_index()

    index = faiss.read_index(INDEX_FILE)
    with open(META_FILE, "rb") as f:
        metadata = pickle.load(f)

    return index, metadata

def search_faiss(query: str, k: int = 3) -> List[str]:
    """
    Search the FAISS index for top-k relevant document chunks.
    """
    index, metadata = load_faiss_index()
    query_embedding = get_embedding(query)

    if not query_embedding:
        return []

    D, I = index.search(np.array([query_embedding]).astype("float32"), k)

    results = []
    for idx in I[0]:
        if idx < len(metadata):
            filename, chunk = metadata[idx]
            results.append(f"From {filename}:\n{chunk.strip()}")

    return results



def _save_index_and_meta(index, meta):
    faiss.write_index(index, INDEX_FILE)
    with open(META_FILE, "wb") as f:
        pickle.dump(meta, f)

def add_document_to_faiss(text: str, source: str = "user_contribution.txt"):
    """
    Incrementally add a single document/text to the FAISS index.
    Persists the new vector and metadata.
    """
    if not text.strip():
        print("[INFO] Empty text, skipping add.")
        return False

    # Load or build
    if not os.path.exists(INDEX_FILE) or not os.path.exists(META_FILE):
        print("[INFO] No index found; building a fresh index first.")
        build_faiss_index()

    index, metadata = load_faiss_index()

    emb = get_embedding(text)
    if not emb:
        print("[ERROR] Could not compute embedding for incremental add.")
        return False

    # Add to index & metadata
    index.add(np.array([emb], dtype="float32"))
    metadata.append((source, text))

    # Persist
    _save_index_and_meta(index, metadata)
    print("[INFO] Added new document to FAISS index.")
    return True
