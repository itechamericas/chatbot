(() => {
  const $ = (sel) => document.querySelector(sel);

  const saved = JSON.parse(localStorage.getItem("settings")||"{}");
  $("#backendUrl").value = saved.backendUrl || (location.protocol + "//" + location.hostname + ":9000");
  $("#apiKey").value = saved.apiKey || "";
  const saveSettings = () => {
    localStorage.setItem("settings", JSON.stringify({
      backendUrl: $("#backendUrl").value.trim(),
      apiKey: $("#apiKey").value.trim()
    }));
    alert("Saved!");
  };
  $("#saveSettings").addEventListener("click", saveSettings);

  const chatLog = $("#chatLog");
  function addMessage(role, text) {
    const div = document.createElement("div");
    div.className = "message " + (role==="user" ? "user" : "bot");
    div.innerHTML = `<div class="role">${role === "user" ? "You" : "Bot"}</div><div class="text"></div>`;
    div.querySelector(".text").textContent = text;
    chatLog.appendChild(div);
    chatLog.scrollTop = chatLog.scrollHeight;
  }

  $("#sendBtn").addEventListener("click", async () => {
    const backend = $("#backendUrl").value.trim();
    const apiKey = $("#apiKey").value.trim();
    const msg = $("#userInput").value.trim();
    const sessionId = $("#sessionId").value.trim() || "default";
    if (!msg) return;
    addMessage("user", msg);
    $("#userInput").value = "";
    try {
      const r = await fetch(backend + "/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": apiKey },
        body: JSON.stringify({ message: msg, session_id: sessionId })
      });
      if (!r.ok) throw new Error("Chat failed: " + r.status);
      const data = await r.json();
      const text = data.response || data.answer || JSON.stringify(data);
      addMessage("bot", text);
    } catch (e) {
      addMessage("bot", "Error: " + e.message);
    }
  });

  $("#addTextBtn").addEventListener("click", async () => {
    const backend = $("#backendUrl").value.trim();
    const apiKey = $("#apiKey").value.trim();
    const text = $("#ingestText").value.trim();
    const source = $("#sourceText").value.trim() || "runtime.txt";
    if (!text) return alert("Paste some text");
    const r = await fetch(backend + "/ingest/text", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": apiKey },
      body: JSON.stringify({ text, source })
    });
    if (r.ok) alert("Added to index!");
    else alert("Ingest failed: " + r.status);
  });

  $("#uploadBtn").addEventListener("click", async () => {
    const backend = $("#backendUrl").value.trim();
    const apiKey = $("#apiKey").value.trim();
    const files = $("#fileInput").files;
    if (!files.length) return alert("Choose files");
    const fd = new FormData();
    for (let f of files) fd.append("files", f, f.name);
    $("#uploadStatus").textContent = "Uploading...";
    try {
      const r = await fetch(backend + "/ingest/upload", {
        method: "POST",
        headers: { "x-api-key": apiKey },
        body: fd
      });
      const data = await r.json();
      $("#uploadStatus").textContent = "Done: " + (data.added || 0) + " chunks";
    } catch (e) {
      $("#uploadStatus").textContent = "Error: " + e.message;
    }
  });

  $("#crawlBtn").addEventListener("click", async () => {
    const backend = $("#backendUrl").value.trim();
    const apiKey = $("#apiKey").value.trim();
    const url = $("#crawlUrl").value.trim();
    const maxPages = parseInt($("#maxPages").value || "30", 10);
    const maxDepth = parseInt($("#maxDepth").value || "2", 10);
    const sameDomain = $("#sameDomain").checked;
    if (!url) return alert("Enter a URL");
    $("#crawlLog").textContent = "Starting crawl...\n";
    try {
      const r = await fetch(backend + "/ingest/url", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": apiKey },
        body: JSON.stringify({ url, max_pages: maxPages, max_depth: maxDepth, same_domain: sameDomain })
      });
      const data = await r.json();
      $("#crawlLog").textContent += JSON.stringify(data, null, 2);
      alert("Crawl complete: " + (data.pages_ingested || 0) + " chunks ingested.");
    } catch (e) {
      $("#crawlLog").textContent += "\nError: " + e.message;
    }
  });

  $("#downloadCsv").addEventListener("click", async () => {
    const backend = $("#backendUrl").value.trim();
    const apiKey = $("#apiKey").value.trim();
    const r = await fetch(backend + "/export/messages.csv", { headers: { "x-api-key": apiKey } });
    if (!r.ok) return alert("Export failed");
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "messages_export.csv";
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  });
})();