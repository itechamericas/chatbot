import os
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
try:
    from .chatbot import get_chat_response
except Exception:
    from chatbot import get_chat_response
try:
    from .database import create_tables, save_message, save_feedback, export_messages_to_csv
except Exception:
    from database import create_tables, save_message, save_feedback, export_messages_to_csv
from dotenv import load_dotenv

from fastapi import File, UploadFile, Form
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse
import aiofiles
import uuid
import base64

# voice utilities
try:
    from .voice import text_to_speech_bytes, speech_to_text
except Exception:
    from voice import text_to_speech_bytes, speech_to_text

DATA_DIR = "data"
AUDIO_TMP = os.path.join(DATA_DIR, "tmp_audio")
os.makedirs(AUDIO_TMP, exist_ok=True)

@app.post("/audio/transcribe")
async def audio_transcribe(file: UploadFile = File(...), language: str = None):
    if os.getenv("INTERNAL_API_KEY") and os.getenv("INTERNAL_API_KEY") != "":
        pass  # optional: add auth header like in /chat if you want

    # Save temp file
    tmp_name = f"{uuid.uuid4()}_{file.filename}"
    tmp_path = os.path.join(AUDIO_TMP, tmp_name)
    async with aiofiles.open(tmp_path, "wb") as out:
        content = await file.read()
        await out.write(content)

    text = speech_to_text(tmp_path, language=language)
    # Optionally delete temp file
    try:
        os.remove(tmp_path)
    except Exception:
        pass
    return {"text": text}

@app.get("/audio/tts")
async def audio_tts(text: str, voice: str = "alloy", format: str = "mp3"):
    audio = text_to_speech_bytes(text, voice=voice, format=format)
    if not audio:
        return JSONResponse({"error": "TTS failed"}, status_code=500)

    fname = f"tts_{uuid.uuid4()}.{format}"
    fpath = os.path.join(AUDIO_TMP, fname)
    with open(fpath, "wb") as f:
        f.write(audio)
    return FileResponse(fpath, media_type=f"audio/{format}", filename=fname)

@app.post("/chat/voice")
async def chat_voice(request: Request, file: UploadFile = File(...), session_id: str = Form("default"), voice: str = Form("alloy")):
    # optional: same auth as /chat
    if request.headers.get("x-api-key") != API_KEY:
        raise HTTPException(status_code=403, detail="Forbidden")

    # Save and transcribe
    tmp_name = f"{uuid.uuid4()}_{file.filename}"
    tmp_path = os.path.join(AUDIO_TMP, tmp_name)
    async with aiofiles.open(tmp_path, "wb") as out:
        content = await file.read()
        await out.write(content)
    text = speech_to_text(tmp_path)
    try:
        os.remove(tmp_path)
    except Exception:
        pass

    # Get chat response
    response = get_chat_response(text)
    message_id = save_message(session_id, text, response)

    # Return audio back (base64) along with text response for simplicity
    audio_bytes = text_to_speech_bytes(response, voice=voice, format="mp3")
    audio_b64 = base64.b64encode(audio_bytes).decode("utf-8") if audio_bytes else ""

    return {"transcript": text, "response_text": response, "response_audio_b64": audio_b64, "message_id": message_id}

@app.post("/feedback")
async def feedback(request: Request):
    if request.headers.get("x-api-key") != API_KEY:
        raise HTTPException(status_code=403, detail="Forbidden")
    body = await request.json()
    message_id = int(body.get("message_id"))
    rating = int(body.get("rating", 0))
    comment = body.get("comment", None)
    save_feedback(message_id, rating, comment)
    return {"ok": True}

@app.get("/export/messages.csv")
async def export_messages():
    path = export_messages_to_csv()
    return FileResponse(path, media_type="text/csv", filename="messages_export.csv")


# Load env variables from .env
load_dotenv()

API_KEY = os.getenv("INTERNAL_API_KEY")

app = FastAPI()

# Enable CORS only for your frontend (replace with your domain)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # <--- change this
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    create_tables()

@app.post("/chat")
async def chat(request: Request):
    # 🔐 API key validation
    if request.headers.get("x-api-key") != API_KEY:
        raise HTTPException(status_code=403, detail="Forbidden")

    body = await request.json()
    user_message = body.get("message", "")
    session_id = body.get("session_id", "default")

    response = get_chat_response(user_message)
    save_message(session_id, user_message, response)
    return {"response": response}
