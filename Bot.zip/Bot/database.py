
import sqlite3

def get_connection():
    conn = sqlite3.connect("data/db.sqlite3")
    conn.row_factory = sqlite3.Row
    return conn

def create_tables():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(r"""
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            user_message TEXT,
            bot_response TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cur.execute(r"""
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER,
            rating INTEGER, -- -1, 0, 1
            comment TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(message_id) REFERENCES messages(id)
        )
    """)
    cur.execute(r"""
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT UNIQUE,
            user_id TEXT,
            meta JSON,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def save_message(session_id, user_message, bot_response):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO messages (session_id, user_message, bot_response) VALUES (?, ?, ?)",
        (session_id, user_message, bot_response),
    )
    conn.commit()
    last_id = cur.lastrowid
    conn.close()
    return last_id

def save_feedback(message_id: int, rating: int, comment: str = None):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO feedback (message_id, rating, comment) VALUES (?, ?, ?)",
        (message_id, rating, comment),
    )
    conn.commit()
    conn.close()

def export_messages_to_csv(csv_path: str = "data/messages_export.csv") -> str:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, session_id, user_message, bot_response, timestamp FROM messages ORDER BY id ASC")
    rows = cur.fetchall()
    conn.close()

    import csv, os
    os.makedirs(os.path.dirname(csv_path), exist_ok=True)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id", "session_id", "user_message", "bot_response", "timestamp"])
        for r in rows:
            writer.writerow([r["id"], r["session_id"], r["user_message"], r["bot_response"], r["timestamp"]])
    return csv_path
